工欲善其事，必先利其器

你的密码学相关的工具和 python 安装好了吗？



对于初学者，以下工具是**很有必要**的：

-   Python 3（建议3.8或更高）
    -   Python安装方法请百度，anaconda以及ide看个人需求
    -   Crypto 库（安装方法请百度“python3安装Crypto库”）
    -   gmpy2 库

以及，以下工具是**建议**的：

-   sagemath
-   python 2
-   ...

以下工具是会**带来便利**的：

-   yafu
-   Google translate
-   CyberChef
-   ...



在你熟练掌握以上工具的使用之后，或者当你感觉到这些工具已经不够便利的时候，是时候开发自己的工具了。

尝试着开发你自己的工具包或者写一个你自己的python库吧



请运行以下代码获得flag

```python
# encode = utf-8
# python3
# pycryptodemo 3.12.0

import Crypto.PublicKey as pk
from hashlib import md5
from functools import reduce

a = sum([len(str(i)) for i in pk.__dict__])
funcs = list(pk.__dict__.keys())
b = reduce(lambda a,b:a+b,[str(i) for i in funcs])
f = md5(b.encode()).hexdigest()
print('TYCTF{' + f + '}')
```

